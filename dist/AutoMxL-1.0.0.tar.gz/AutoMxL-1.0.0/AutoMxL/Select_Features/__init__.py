"""
Contains modules related to features selection

Modules :
- Categorical_Data
- Select_Features
"""

__all__ = ['Select_Features']
